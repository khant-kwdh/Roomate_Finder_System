<%@ page contentType="text/html;charset=UTF-8" session="true" %>
<%
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RoommateFinder - FAQ</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
<style>
:root {
    --primary: #1a73e8;
    --secondary: #6c757d;
    --light: #f8f9fa;
    --dark: #343a40;
    --gold: #ffc107;
}
* { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { background-color:#f9fafb; color:#333; line-height:1.6; min-height:100vh; display:flex; flex-direction:column; }
.container { width:90%; max-width:1200px; margin:0 auto; padding:20px; }

/* Header */
header { background:white; box-shadow:0 2px 10px rgba(0,0,0,0.1); position:sticky; top:0; z-index:100; }
.header-content { display:flex; justify-content:space-between; align-items:center; padding:15px 0; flex-wrap:wrap; }
.logo { display:flex; align-items:center; font-size:24px; font-weight:700; color:var(--primary); }
.logo span { color:var(--gold); }
.logo i { margin-right:10px; font-size:28px; }
nav ul { display:flex; list-style:none; flex-wrap:wrap; }
nav ul li { margin-left:20px; }
nav ul li a { font-weight:500; color:var(--dark); text-decoration:none; transition:color 0.3s; }
nav ul li a:hover, nav ul li a.active { color:var(--primary); }
.nav-buttons { display:flex; gap:10px; }
.btn { display:inline-block; padding:10px 20px; background:var(--primary); color:white; border-radius:4px; font-weight:600; border:none; cursor:pointer; transition:all 0.3s ease; text-decoration:none; text-align:center; }
.btn:hover { background:#1557b7; transform:translateY(-2px); }
.btn-outline { background:transparent; border:2px solid var(--primary); color:var(--primary); }
.btn-outline:hover { background:var(--primary); color:white; }

/* Hero */
.hero { padding:80px 20px; background: linear-gradient(135deg, rgba(26,115,232,0.85)0%, rgba(26,115,232,0.8)100%), url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'); background-size:cover; background-position:center; color:white; text-align:center; border-radius:8px; margin:40px 0; }
.hero h1 { font-size:42px; margin-bottom:20px; }
.hero p { font-size:18px; max-width:600px; margin:0 auto 30px; opacity:0.9; }

/* Dashboard Cards */
.dashboard { padding:40px 0; }
.dashboard-cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:25px; }
.card { background:white; border-radius:12px; box-shadow:0 5px 15px rgba(0,0,0,0.05); overflow:hidden; text-align:center; }
.card-header { background:var(--primary); color:white; padding:15px; font-weight:bold; font-size:16px; }
.card-body { padding:20px; }
.stat { font-size:32px; font-weight:bold; color:var(--dark); margin-bottom:10px; }
.stat-desc { color:var(--secondary); margin-bottom:15px; }
.btn { display:inline-block; padding:8px 15px; border-radius:6px; text-decoration:none; color:white; background:var(--primary); font-weight:500; transition:0.3s; }
.btn:hover { background:#1557b7; }

/* Table */
section h2 { font-size:20px; margin:30px 0 15px; color:var(--primary); border-bottom:2px solid #eee; padding-bottom:5px; }
table { width:100%; border-collapse:collapse; background:white; border-radius:8px; overflow:hidden; margin-bottom:40px; }
th,td { padding:12px; border-bottom:1px solid #eee; text-align:left; }
th { background:var(--primary); color:white; }
tr:hover { background:#f1f1f1; }

/* Footer */
footer { background:var(--dark); color:white; padding:60px 0 30px; margin-top:auto; }
.footer-content { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:40px; margin-bottom:40px; }
.footer-column h3 { margin-bottom:20px; position:relative; padding-bottom:10px; }
.footer-column h3::after { content:''; position:absolute; left:0; bottom:0; width:40px; height:2px; background:var(--primary); }
.footer-column ul { list-style:none; }
.footer-column ul li { margin-bottom:12px; }
.footer-column a { color:#e2e8f0; text-decoration:none; transition:color 0.3s; }
.footer-column a:hover { color:white; }
.footer-social { display:flex; gap:15px; margin-top:10px; }
.footer-social a { display:flex; align-items:center; justify-content:center; width:35px; height:35px; border-radius:50%; background:rgba(255,255,255,0.1); transition:all 0.3s; }
.footer-social a:hover { background:var(--primary); }
.footer-bottom { text-align:center; padding-top:20px; border-top:1px solid rgba(255,255,255,0.1); }

/* Responsive */
@media (max-width:968px) { .dashboard-cards { grid-template-columns:1fr; } }
@media (max-width:768px){
    .header-content { flex-direction:column; text-align:center; }
    nav ul { justify-content:center; margin:20px 0; flex-wrap:wrap; }
    nav ul li { margin:5px 10px; }
    .hero h1 { font-size:32px; }
    .section-title { font-size:28px; }
}

/* FAQ Container */
.container { width:90%; max-width:1000px; margin:40px auto; background:white; padding:30px; border-radius:8px; box-shadow:0 5px 15px rgba(0,0,0,0.05); }
h1.display-4 { color:var(--primary); text-align:center; margin-bottom:20px; }
p.lead { text-align:center; margin-bottom:40px; }

/* Search */
#faqSearch { border-radius:20px 0 0 20px; padding:12px 20px; border:1px solid #ccc; flex:1; }
#faqSearch:focus { outline:none; border-color:var(--primary); box-shadow:none; }
.btn-search { border-radius:0 20px 20px 0; padding:12px 20px; background:var(--primary); border:none; color:white; }

/* Accordion */
.category-title { color:var(--primary); font-weight:600; border-bottom:2px solid var(--primary); padding-bottom:10px; margin-top:40px; margin-bottom:20px; }
.accordion-button { font-weight:500; padding:1rem 1.25rem; }
.accordion-button:not(.collapsed) { background-color:var(--light); color:var(--primary); }
.accordion-body { background-color:#f8f9fa; padding:1.5rem; }

/* Support Card */
.support-card { border:none; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.08); margin-top:40px; }
.support-icon { font-size:3rem; color:var(--primary); }

/* Footer */
/* Footer */
footer {
    background: var(--dark);
    color: #e2e8f0;
    padding: 60px 20px 30px;
    margin-top: auto;
    font-size: 0.95rem;
}
.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 40px;
    margin-bottom: 30px;
}
.footer-column h3 {
    margin-bottom: 20px;
    font-size: 1.2rem;
    position: relative;
    padding-bottom: 10px;
    color: #fff;
}
.footer-column h3::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 40px;
    height: 2px;
    background: var(--primary);
}
.footer-column ul {
    list-style: none;
    padding: 0;
    margin: 0;
}
.footer-column ul li {
    margin-bottom: 12px;
}
.footer-column a {
    color: #cbd5e1;
    text-decoration: none;
    transition: all 0.3s ease;
}
.footer-column a:hover {
    color: #fff;
    text-decoration: underline;
}
.footer-social {
    display: flex;
    gap: 12px;
    margin-top: 15px;
}
.footer-social a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    transition: all 0.3s ease;
}
.footer-social a:hover {
    background: var(--primary);
    color: #fff;
    transform: translateY(-2px);
}
.footer-bottom {
    text-align: center;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
    padding-top: 20px;
    color: #9ca3af;
    font-size: 0.9rem;
}

/* Responsive Adjustments */
@media (max-width:768px) {
    .footer-content {
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
}
@media (max-width:480px) {
    .footer-content {
        grid-template-columns: 1fr;
        gap: 15px;
        text-align: center;
    }
    .footer-social { justify-content: center; }
}

/* Responsive */
@media (max-width:768px) { nav ul { justify-content:center; margin:20px 0; flex-wrap:wrap; } nav ul li { margin:5px 10px; } }
</style>
</head>
<body>

<!-- Header -->
<header>
<div class="container header-content">
    <div class="logo"><i class="fas fa-house-user"></i> Roommate<span>Finder</span></div>
    <nav>
        <ul>
            <li><a href="index.jsp">Home</a></li>
            <li><a href="aboutus.jsp">About Us</a></li>
            <li><a href="contact.jsp">Contact</a></li>
            <li><a href="faq.jsp" class="active">FAQ</a></li>
            
        </ul>
    </nav>
    <div class="nav-buttons">
        <%
            if(username != null){
        %>
            <a href="profile.jsp" class="btn btn-outline"><i class="fas fa-user-circle"></i> <%= username %></a>
            <a href="logout.jsp" class="btn">Logout</a>
        <%
            } else {
        %>
            <a href="login.jsp" class="btn btn-outline">Login</a>
            <a href="register.jsp" class="btn">Register</a>
        <%
            }
        %>
    </div>
</div>
</header>

<!-- FAQ Content -->
<div class="container">
    <h1 class="display-4">Frequently Asked Questions</h1>
    <p class="lead">Find answers to common questions about our roommate matching service</p>

    <div class="input-group mb-4">
        <input type="text" id="faqSearch" placeholder="Search questions...">
        <button class="btn btn-search" type="button" id="searchButton"><i class="fas fa-search"></i></button>
    </div>

    <div class="accordion" id="faqAccordion">
        <h2 class="category-title">Account & Profile Questions</h2>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true">
                    How do I create an account?
                </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show">
                <div class="accordion-body">
                    Click "Sign Up" at the top, provide your email, password, and fill out your info.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                    Can I change my profile information later?
                </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Yes, update your profile anytime. Keeping info current improves matches.
                </div>
            </div>
        </div>

        <h2 class="category-title">Matching Process</h2>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                    How does the matching algorithm work?
                </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Matching considers lifestyle, sleep habits, cleanliness, interests, and schedule compatibility.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingFour">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
                    Can I search for roommates in a specific area?
                </button>
            </h2>
            <div id="collapseFour" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Yes, use filters to find roommates in specific cities, neighborhoods, or near universities.
                </div>
            </div>
        </div>

        <h2 class="category-title">Safety & Privacy</h2>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingFive">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive">
                    Is my personal information secure?
                </button>
            </h2>
            <div id="collapseFive" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Data is secure and never shared without permission. Encryption is used.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingSix">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix">
                    How can I report a suspicious profile?
                </button>
            </h2>
            <div id="collapseSix" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Click "Report" on suspicious profiles. Our team reviews them promptly.
                </div>
            </div>
        </div>

        <h2 class="category-title">Payment & Fees</h2>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingSeven">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven">
                    Is there a fee to use this service?
                </button>
            </h2>
            <div id="collapseSeven" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Basic usage is free. Premium features are available via subscription.
                </div>
            </div>
        </div>
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingEight">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight">
                    What payment methods do you accept?
                </button>
            </h2>
            <div id="collapseEight" class="accordion-collapse collapse">
                <div class="accordion-body">
                    Major credit cards, PayPal, and bank transfers in select regions.
                </div>
            </div>
        </div>
    </div>

    <!-- Support Card -->
    <div class="support-card text-center p-5 mt-5">
        <i class="fas fa-headset support-icon mb-3"></i>
        <h3>Still have questions?</h3>
        <p class="text-muted">Our support team is here to help you</p>
        <a href="contact.jsp" class="btn mt-2">Contact Support</a>
    </div>
</div>

<!-- Footer -->
<footer>
<div class="container">
<div class="footer-content">
<div class="footer-column">
<h3>RoommateFinder</h3>
<p>Helping university students find compatible roommates since 2023.</p>
<div class="footer-social">
<a href="#"><i class="fab fa-facebook-f"></i></a>
<a href="#"><i class="fab fa-twitter"></i></a>
<a href="#"><i class="fab fa-instagram"></i></a>
<a href="#"><i class="fab fa-linkedin-in"></i></a>
</div>
</div>
<div class="footer-column">
<h3>Quick Links</h3>
<ul>
<li><a href="index.jsp">Home</a></li>
<li><a href="aboutus.jsp">About Us</a></li>
<li><a href="contact.jsp">Contact</a></li>
<li><a href="faq.jsp">FAQ</a></li>
</ul>
</div>
<div class="footer-column">
<h3>Resources</h3>
<ul>
<li><a href="#">Roommate Tips</a></li>
<li><a href="#">University Housing</a></li>
<li><a href="#">FAQ</a></li>
</ul>
</div>
<div class="footer-column">
<h3>Legal</h3>
<ul>
<li><a href="#">Terms of Service</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Cookie Policy</a></li>
</ul>
</div>
</div>
<div class="footer-bottom">© <%= java.time.Year.now() %> RoommateFinder. All rights reserved.</div>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const faqSearch = document.getElementById('faqSearch');
    const searchButton = document.getElementById('searchButton');

    function performSearch() {
        const searchTerm = faqSearch.value.toLowerCase();
        const items = document.querySelectorAll('.accordion-item');
        items.forEach(item => {
            const question = item.querySelector('.accordion-button').textContent.toLowerCase();
            const answer = item.querySelector('.accordion-body').textContent.toLowerCase();
            if(question.includes(searchTerm) || answer.includes(searchTerm)){
                item.style.display='block';
                const collapse = item.querySelector('.accordion-collapse');
                if(!collapse.classList.contains('show')){
                    new bootstrap.Collapse(collapse, {toggle:true});
                }
            } else { item.style.display='none'; }
        });
    }

    searchButton.addEventListener('click', performSearch);
    faqSearch.addEventListener('keyup', function(e){ if(e.key==='Enter') performSearch(); });
});
</script>
</body>
</html>
